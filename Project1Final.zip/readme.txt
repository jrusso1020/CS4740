In order to run our project, you can simply place the project into the root of the data folders and 
run python ngram_model.py. In the main function of our project, our project is divided into multiple sections
that you can uncomment and run, which are clasify, spellcheck and our tuning procedure for interpolation.
